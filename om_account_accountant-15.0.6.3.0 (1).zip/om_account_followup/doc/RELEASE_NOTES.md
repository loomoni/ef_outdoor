## Module <om_account_followup>

#### 16.07.2022
#### Version 15.0.2.3.0
##### IMP
- Date Format on Report

#### 14.07.2022
#### Version 15.0.2.2.0
##### IMP
- german translation

#### 15.04.2022
#### Version 15.0.2.0.0
##### IMP
- remove warning

#### 15.04.2022
#### Version 15.0.1.1.0
##### IMP
- turkish translation

#### 03.03.2022
#### Version 15.0.1.0.0
##### ADD
- Initial commit



